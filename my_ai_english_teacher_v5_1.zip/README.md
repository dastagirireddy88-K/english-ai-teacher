# My AI English Teacher V5.1
Android-first starter with microphone speech recognition, teacher voice, practice modes and GitHub Actions APK build.

IMPORTANT: This starter has a local coaching fallback. Do not put an OpenAI API key in the APK. A secure backend should be used for the real AI connection.

PHONE-ONLY BUILD:
1. Create a GitHub account.
2. Create a new empty repository.
3. Upload the contents of this ZIP, preserving .github/workflows/build-apk.yml.
4. Open the repository's Actions tab.
5. Select Build Android APK.
6. Tap Run workflow.
7. Open the completed run.
8. Download the english-teacher-v5-1-apk artifact.
9. Extract it and install app-debug.apk.

If the GitHub mobile UI does not allow the full folder structure to be uploaded, use GitHub in your phone browser with desktop site enabled.
